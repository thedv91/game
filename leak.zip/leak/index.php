<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <title>Memory Game</title>


    <script type="text/javascript" src="lib/jquery-3.0.0.min.js"></script>

    <script type="text/javascript" src="phaser.min.js"></script>

    <script type="text/javascript" src="script.js"></script>

    <style type="text/css">
        body {
            margin: 0;
        }
        /*canvas {
            margin: 0px auto;
        }*/
    </style>

</head>
<body>
   
    <!--<h3 style="font-family: AvenirNextLTProBold; font-size: 48px; ">MATCH THE PAIR</h3>-->
    <div id="gameDiv"></div>
</body>

</html>